﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dijkstry
{
    internal class NodeG1
    {
        public int data;


        //dodane przeze mnie
        public NodeG1(int data)
        {
            this.data = data;
        }
    }
}
