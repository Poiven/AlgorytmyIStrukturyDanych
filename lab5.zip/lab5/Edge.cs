﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5
{
    internal class Edge
    {
        public NodeG1 start;
        public NodeG1 end;
        public int weight;
    }
}
