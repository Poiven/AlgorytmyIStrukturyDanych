using System.Xml.Linq;

namespace kodowanieHuffmana
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();



        }
        int zmienna;

        private void button1_Click(object sender, EventArgs e)
        {
            string tekst = textBox1.Text;

        }
        public Dictionary<char,int> czestosc(string teskt)
        {
            var slownikCzestosci = new Dictionary<char, int>();

            foreach(var litera in teskt)
            {
                if (slownikCzestosci.ContainsKey(litera))
                {
                    slownikCzestosci[litera]++;
                }
                else
                {
                    slownikCzestosci[litera] = 1;
                }
            }
            return slownikCzestosci;
        }
        void wglab(NodeG n, string kod)
        {
            if (n != null)
            {
                wglab(n.lewe, kod + "0");
                wglab(n.prawa, kod + "1");
            }
        }
    }
}