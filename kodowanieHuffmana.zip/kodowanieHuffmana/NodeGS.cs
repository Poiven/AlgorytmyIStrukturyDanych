﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kodowanieHuffmana
{
    internal class NodeGS:NodeG
    {
        char symbol;
        public NodeGS(int data)
        {
            this.data = data;
        }
    }
}
