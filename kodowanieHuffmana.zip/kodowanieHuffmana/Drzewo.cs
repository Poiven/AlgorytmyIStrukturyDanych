﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kodowanieHuffmana
{
    internal class Drzewo
    {


        // .orderBy(n=>n.data).ThenBy(n=>n.GetType()==typeof(NodeGS)?0:1).ToList();
    }
}
