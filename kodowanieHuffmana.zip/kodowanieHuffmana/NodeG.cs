﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kodowanieHuffmana
{
    internal class NodeG
    {
        public NodeG lewe;
        public NodeG prawa;
        public NodeG rodzic;
        public int data; //czestosc

        public NodeG(int data)
        {
            this.data = data;
        }
        public NodeG()
        {

        }
    }
}
